import os
import json
import nltk
import torch
import pickle
import numpy as np
from nltk.corpus import stopwords
from moverscore import get_idf_dict, word_mover_score
from transformers import pipeline, AutoModelForSequenceClassification, AutoTokenizer, TextClassificationPipeline
stopwords = stopwords.words("english")

class RewardAgent:
    def __init__(self, args, tokenizer, rewards_model):
        self.args = args
        self.rewards_model = rewards_model[0]
        self.tokenizer = rewards_model[1]
        model = AutoModelForSequenceClassification.from_pretrained(self.args.pretrained_pss_score_model)
        tokenizer = AutoTokenizer.from_pretrained(self.args.pretrained_pss_score_model)
        self.pss_score_model = TextClassificationPipeline(model=model, tokenizer=tokenizer, return_all_scores=True, device=self.args.gpu)

        model = AutoModelForSequenceClassification.from_pretrained(self.args.pretrained_pol_score_model)
        tokenizer = AutoTokenizer.from_pretrained(self.args.pretrained_pol_score_model)
        self.pol_score_model = TextClassificationPipeline(model=model, tokenizer=tokenizer, return_all_scores=True, device=self.args.gpu)
        

        model = AutoModelForSequenceClassification.from_pretrained(self.args.pretrained_emp_score_model)
        tokenizer = AutoTokenizer.from_pretrained(self.args.pretrained_emp_score_model)
        self.emp_score_model = TextClassificationPipeline(model=model, tokenizer=tokenizer, return_all_scores=True, device=self.args.gpu)
        
        
    def process_context(self, context, strategy, pol, emp, role):
        context_ids = [self.tokenizer.cls_token_id]
        for uttr, strategy, pol, emp, role in zip(context, strategy, pol, emp, role):
            if role == "client":
                utterance = " ".join(uttr)
            elif role == "therapist":
                utterance = "["+strategy+"]" + " " + "["+pol+"]" + " " + "["+emp+"]" + " " + " ".join(uttr)
            context_ids = context_ids + self.tokenizer.convert_tokens_to_ids(self.tokenizer.tokenize(utterance)) + [self.tokenizer.sep_token_id]
        
        while len(context_ids) > self.args.max_context_length:
            cut_idx = context_ids.index(self.tokenizer.sep_token_id, -self.args.max_context_length+1)
            context_ids = [self.tokenizer.cls_token_id] + context_ids[cut_idx:]
        
        context_token_type_ids = [0] * len(context_ids)
        context_attenttion_mask = [1] * len(context_ids)
        
        return context_ids, context_token_type_ids, context_attenttion_mask
    
    def process_response(self, uttr, is_next_uttr=False):
        if is_next_uttr:
            utterance = " ".join(uttr)
            utterance_ids = [self.tokenizer.cls_token_id] + self.tokenizer.convert_tokens_to_ids(self.tokenizer.tokenize(utterance)) + [self.tokenizer.sep_token_id]
            uttr_token_type_ids = [0] * len(utterance_ids)
        else:
            utterance = uttr   
            utterance_ids = self.tokenizer.convert_tokens_to_ids(self.tokenizer.tokenize(utterance)) + [self.tokenizer.sep_token_id]
            uttr_token_type_ids = [1] * len(utterance_ids)
        uttr_attention_mask = [1] * len(utterance_ids)
        return utterance_ids, uttr_token_type_ids, uttr_attention_mask
    
    #Modify from here
    @torch.no_grad()
    def cc(self, data, context, references, responses):
        def rewards_model_dataset(idx, data, response):
            response_ids, response_token_type_ids, response_attention_mask = self.process_response(
                response, 
                response_kws
            )
            context_ids, context_token_type_ids, context_attention_mask = self.process_context(
                    data["context_txt"][idx],
                    data["context_pss_seqs_txt"][idx],
                    data["context_pol_seqs_txt"][idx],
                    data["context_emp_seqs_txt"][idx], 
                    data["context_role_txt"][idx],
                )
                input_ids = context_ids + response_ids
                token_type_ids = context_token_type_ids + response_token_type_ids
                attention_mask = context_attention_mask + response_attention_mask

            return torch.tensor(input_ids, dtype=torch.long).to(self.args.device), \
                   torch.tensor(token_type_ids, dtype=torch.long).to(self.args.device), \
                   torch.tensor(attention_mask, dtype=torch.long).to(self.args.device)
       
        context_consistency_rewards = list()
        for ctx, ref, (idx, response) in zip(context, references, enumerate(responses)):
            # context
            idf_refs_1 = get_idf_dict([ctx] + [response])
            idf_refs_2 = get_idf_dict([ref] + [response])
            
            # Compute MoverScores
            ms1 = word_mover_score([ctx], [response], idf_refs_1, idf_refs_1, stop_words=[], n_gram=1, remove_subwords=True)
            ms2 = word_mover_score([ref], [response], idf_refs_2, idf_refs_2, stop_words=[], n_gram=1, remove_subwords=True)
            
            con_const_reward = 0.5 * (ms1[0] + ms2[0])
            context_consistency_rewards.append(con_coher_reward)
            
        return np.mean(context_consistency_rewards), np.array(context_consistency_rewards)
    
    def pss(self, data, response_pss_score):
        delta1 = 1.0
        next_uttr_pss_scores = data["next_uttr_pss_score"]
        response = data["response"]
        reference = data["reference"]
        dialog_turn = data["dialog_turn"]
        assert len(next_uttr_pss_scores) == len(response_pss_score)

        pss_rewards = list()

        for turn, res_pss_score, next_uttr_pss_score, res, ref in zip(dialog_turn, response_pss_score, next_uttr_pss_scores, response, reference):
            reward = self.get_pss_score(ref) - delta1 * self.get_pss_score(res)
            pss_rewards.append(reward)
        return np.mean(pss_rewards), np.array(pss_rewards)

    def pol(self, data, response_pol_score):
        delta2 = 1.0
        next_uttr_pol_scores = data["next_uttr_pol_score"]
        response = data["response"]
        reference = data["reference"]
        dialog_turn = data["dialog_turn"]
        assert len(next_uttr_pol_scores) == len(response_pol_score)

        pol_rewards = list()

        for turn, res_pol_score, next_uttr_pol_score, res, ref in zip(dialog_turn, response_pol_score, next_uttr_pol_scores, response, reference):
            reward = self.get_pol_score(ref) - delta2 * self.get_pol_score(res)
            pol_rewards.append(reward)
        return np.mean(pol_rewards), np.array(pol_rewards)

    def emp(self, data, response_emp_score):
        delt3 = 1.0
        next_uttr_emp_scores = data["next_uttr_emp_score"]
        response = data["response"]
        reference = data["reference"]
        dialog_turn = data["dialog_turn"]
        assert len(next_uttr_emp_scores) == len(response_emp_score)

        emp_rewards = list()

        for turn, res_emp_score, next_uttr_emp_score, res, ref in zip(dialog_turn, response_emp_score, next_uttr_emp_scores, response, reference):
            reward = self.get_emp_score(ref) - delta3 * self.get_emp_score(res)
            emp_rewards.append(reward)
        return np.mean(emp_rewards), np.array(emp_rewards)

    def div(self, data):
        response = data["response"]
        reference = data["reference"]
        dialog_turn = data["dialog_turn"]
        assert len(next_uttr_emp_scores) == len(response_emp_score)

        div_rewards = list()
        n=2

        for turn, res in zip(dialog_turn, response):
            
            tokens = res.strip().split()
            if len(tokens) < n:
                return 0.0
            ngrams = list(zip(*[tokens[i:] for i in range(n)]))
            unique_ngrams = set(ngrams)
            
            reward = len(unique_ngrams) / len(ngrams)
            div_rewards.append(reward)
        return np.mean(div_rewards), np.array(div_rewards)

    

    def get_pss_score(self, utterance):
        pss_scores = self.pss_score_model(utterance)
        score = 0.0
        for item in pss_scores[0]:
            score += item["score"]
        return score

    def get_pol_score(self, utterance):
        pol_scores = self.pol_score_model(utterance)
        score = 0.0
        for item in pol_scores[0]:
            score += item["score"]
        return score

    def get_emp_score(self, utterance):
        emp_scores = self.emp_score_model(utterance)
        score = 0.0
        for item in emp_scores[0]:
            score += item["score"]
        return score

    def get_cc_score(self, utterance, context):
        # context
        idf_refs_1 = get_idf_dict([context] + [utterance])
            
        # Compute MoverScores
        cc_scores = word_mover_score([context], [utterance], idf_refs_1, idf_refs_1, stop_words=[], n_gram=1, remove_subwords=True)
        score = 0.0
        for item in cc_scores[0]:
            score += item["score"]
        return score 

    def get_div_score(self, utterance):
        n=2
        tokens = utterance.strip().split()
        if len(tokens) < n:
            return 0.0
        ngrams = list(zip(*[tokens[i:] for i in range(n)]))
        unique_ngrams = set(ngrams)

        div_scores = len(unique_ngrams) / len(ngrams)
        score = 0.0
        for item in div_scores[0]:
            score += item["score"]
        return score

    def get_rewards(self, data, responses, is_evaluate=False):
        
        response_sssc_score = [
            self.get_pss_score(utterance)
            for utterance in responses
        ]
        pss_reward, batch_pss_rewards = self.pss(data, response_sssc_score)
        
        response_epsc_score = [
            self.get_pol_score(utterance)
            for utterance in responses
        ]
        pol_reward, batch_pol_rewards = self.pss(data, response_epsc_score)
        

       response_eesc_score = [
            self.get_emp_score(utterance)
            for utterance in responses
        ]
        emp_reward, batch_emp_rewards = self.pss(data, response_eesc_score)

        response_cc_score = [
            self.get_cc_score(utterance)
            for utterance in responses
        ]
        cc_reward, batch_cc_rewards = self.pss(data, response_cc_score)

        response_div_score = [
            self.get_div_score(utterance)
            for utterance in responses
        ]
        div_reward, batch_div_rewards = self.pss(data, response_div_score)
         
        
        eval_rewards = pss_reward + pol_reward + \
                emp_reward + cc_reward + div_reward

        rewards = self.args.pss_reward_weight * pss_reward + \
                  self.args.pol_reward_weight *pol_reward + \
                  self.args.emp_weight * emp_reward + \
                  self.args.cc_reward_weight * cc_reward + \
                  self.args.div_reward_weight * div_reward
        batch_rewards = self.args.pss_reward_weight * batch_pss_reward + \
                  self.args.pol_reward_weight * batch_pol_reward + \
                  self.args.emp_weight * batch_emp_reward + \
                  self.args.cc_reward_weight * batch_cc_reward + \
                  self.args.div_reward_weight * batch_div_reward
        return rewards, batch_rewards, eval_rewards
    
    